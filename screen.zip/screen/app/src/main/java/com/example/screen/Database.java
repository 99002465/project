package com.example.screen;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
@androidx.room.Database(entities = {category.class},version = 1)
public abstract class Database extends RoomDatabase {
    private static Database instance;
    public abstract Dao dao();
    public static synchronized Database getInstance(Context context){
        if (instance==null){
            instance= Room.databaseBuilder(context.getApplicationContext(),Database.class,"note_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomcallback)
                    .build();
        }
        return  instance;
    }
  private  static RoomDatabase.Callback roomcallback=new RoomDatabase.Callback(){
      @Override
      public void onCreate(@NonNull SupportSQLiteDatabase db) {
          super.onCreate(db);
          new PopulateDbAsyncTask(instance).execute();
      }
  };
    private static class  PopulateDbAsyncTask extends AsyncTask<Void,Void,Void> {
        private Dao dao;
        private PopulateDbAsyncTask(Database db){
            dao=db.dao();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            dao.insert(new category("Title1",1));
            dao.insert(new category("Title2",2));
            dao.insert(new category("Title3",3));
            return null;
        }
    }
}