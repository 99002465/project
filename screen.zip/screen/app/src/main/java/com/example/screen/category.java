package com.example.screen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import android.os.Bundle;
@Entity(tableName = "category_table")
public class category {
     private String catname;
     @PrimaryKey(autoGenerate = true)
     private int  id;
    public category(String catname,int id){
        this.catname=catname;
        this.id=id;
    }
    public String getCatname() {
        return catname;
    }

    public int getId() {
        return id;
    }



    public void setId(int id) {
        this.id = id;
    }
}