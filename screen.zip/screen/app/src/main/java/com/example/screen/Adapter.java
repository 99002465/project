package com.example.screen;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.NoteHolder> {
    private List<category> cat=new ArrayList<>();
    @NonNull
    @Override
    public NoteHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item,parent, false );
        return new NoteHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteHolder holder, int position) {
        category currentcat =cat.get(position);
        holder.textViewTitle.setText(currentcat.getCatname());
        holder.getTextViewId.setText(currentcat.getId());
    }



    @Override
    public int getItemCount() {
        return cat.size();
    }
    public void setcat(List<category> cat){
        this.cat=cat;
        notifyDataSetChanged();
    }
    class NoteHolder extends RecyclerView.ViewHolder{
         private TextView textViewTitle;
         private TextView getTextViewId;
        public NoteHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitle=itemView.findViewById(R.id.text_view_catname);
            getTextViewId=itemView.findViewById(R.id.text_view_id);

        }
    }
}
