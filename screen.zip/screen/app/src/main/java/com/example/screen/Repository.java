package com.example.screen;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;
import androidx.loader.content.AsyncTaskLoader;
import androidx.room.Delete;
import androidx.room.Update;

import java.util.List;
import java.util.Locale;

public class Repository {
    private  Dao dao;
    private LiveData<List<category>> allNotes;
    public Repository(Application application){
        Database database=Database.getInstance(application);
        dao=database.dao();
        allNotes=dao.getAllNotes();

    }
    public void insert(category cat){
        new InsertNoteAsyncTask(dao).execute(cat);
    }
    public void update(category cat){
        new UpdateNoteAsyncTask(dao).execute(cat);
    }
    public void delete(category cat){
        new DeleteNoteAsyncTask(dao).execute(cat);
    }
    public void deleteAllNotes(){
        new DeleteAllNoteAsyncTask(dao).execute();
    }
    public LiveData<List<category>> getAllNotes(){
        return allNotes;
    }
    private static class InsertNoteAsyncTask extends AsyncTask <category,Void,Void >{
        private Dao dao;
        private InsertNoteAsyncTask(Dao dao){
            this.dao=dao;

        }
        @Override
        protected Void doInBackground(category... categories){
            dao.insert(categories[0]);
            return null;
        }
    }

    private static class UpdateNoteAsyncTask extends AsyncTask <category,Void,Void>{
        private Dao dao;
        private UpdateNoteAsyncTask(Dao dao){
            this.dao=dao;

        }
        @Override
        protected Void doInBackground(category... categories){
            dao.update(categories[0]);
            return null;
        }
    }

    private static class DeleteNoteAsyncTask extends AsyncTask <category,Void,Void>{
        private Dao dao;
        private DeleteNoteAsyncTask(Dao dao){
            this.dao=dao;

        }
        @Override
        protected Void doInBackground(category... categories){
            dao.delete(categories[0]);
            return null;
        }
    }
    private static class DeleteAllNoteAsyncTask extends AsyncTask<category,Void,Void> {
        private Dao dao;
        private DeleteAllNoteAsyncTask(Dao dao){
            this.dao=dao;

        }
        @Override
        protected Void doInBackground(category... categories){
            dao.deleteAllnotes();
            return null;
        }
    }
}
