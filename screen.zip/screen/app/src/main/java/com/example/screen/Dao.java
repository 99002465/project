package com.example.screen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import android.os.Bundle;

import java.util.List;

@androidx.room.Dao
public interface Dao  {
   @Insert
   void insert(category cat);
   @Update
   void update (category cat);
   @Delete
    void delete(category cat);
   @Query("DELETE FROM category_table")
    void deleteAllnotes();
   @Query("SELECT * FROM category_table ORDER BY id DESC")
    LiveData<List<category>> getAllNotes();

}