package com.example.screen;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class ViewModel extends AndroidViewModel {
private Repository repo;
private LiveData<List<category>> allNotes;

    public ViewModel(@NonNull Application application) {
        super(application);
        repo=new Repository(application);
        allNotes=repo.getAllNotes();

    }
    public void insert(category cat){
        repo.insert(cat);
    }
    public void update(category cat){
        repo.update(cat);
    }
    public void delete(category cat){
        repo.delete(cat);
    }
    public void deleteAllNotes(){
        repo.deleteAllNotes();
    }
    public LiveData<List<category>> getAllNotes(){
        return allNotes;
    }
}
